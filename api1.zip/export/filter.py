import streamlit as st
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.platypus import Table as ReportLabTable, TableStyle,SimpleDocTemplate
from reportlab.lib import colors
from reportlab.lib.units import inch
import requests
from streamlit_option_menu import option_menu
from streamlit_extras.stylable_container import stylable_container
from pathlib import Path
from borb.pdf.document.document import Document
from borb.pdf.page.page import Page
from borb.pdf.canvas.layout.page_layout.multi_column_layout import SingleColumnLayout
from borb.pdf.canvas.layout.table.fixed_column_width_table import FixedColumnWidthTable as Table
from borb.pdf.canvas.layout.text.paragraph import Paragraph
from borb.pdf.canvas.layout.layout_element import Alignment
from borb.pdf.canvas.layout.image.image import Image
from borb.pdf.pdf import PDF
from borb.pdf.canvas.color.color import HexColor
from decimal import Decimal
from streamlit_pdf_viewer import pdf_viewer

# API Adress around Line 77

st.set_page_config(page_title="Data",layout="wide")

# --- PDF Export Function ---
def print_pdf():
    custom = (20 * inch, 10 * inch)
    pdf = SimpleDocTemplate("Data/export.pdf", pagesize=custom, topMargin=0.3*inch, bottomMargin=0.2*inch)
    table_data = []  # Start with the column headers
    table_data.append(columns_selection)
    for i, row in fildata.iterrows():
        table_data.append(list(row))
    table = ReportLabTable(table_data)
    table_style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.whitesmoke),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 12),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
    ])

    table.setStyle(table_style)
    pdf_table = []
    pdf_table.append(table)
    pdf.build(pdf_table)
    
colm1, colm2, colm3 = st.columns([1, 3, 1])
with colm2:
    selected = option_menu(
        menu_title=None,
        options=["Search", "Personal info"],
        icons=["search", "file-earmark-person"],
        default_index=0,
        orientation="horizontal",
        styles={
            "container": {"background-color": "transparent"},
            "icon": {"color": "ST_COLOR_PALETTE"},
            "nav-link-selected": {"background-color": "ST_COLOR_PALETTE"},
        }
    )

# --- Load Data ---
with st.spinner('Getting Info...'):
    try:
        # --- API Acess Here ---
        indata = requests.get('https://filter-api.glitch.me/api/users').json()
        flattened_data = []
        for item in indata:
            details = item.get("details", {})
            user_details = details.get("user_details", {})
            personal_info_1 = details.get("personal_info_1", {})
            personal_info_2 = details.get("personal_info_2", {})
            personal_info_3 = details.get("personal_info_3", {})
            social_status_of_differentially_abled = details.get("social_status_of_differentially_abled", {})
            combined_info = {**user_details, **personal_info_1, **personal_info_2, **personal_info_3, **social_status_of_differentially_abled}
            flattened_data.append(combined_info)
            df = pd.DataFrame(flattened_data)

    except requests.exceptions.RequestException as e:
        st.error(f"Error fetching data: {e}")
        df = pd.DataFrame()  # Empty DataFrame on error

# --- Menu Bar ---

if selected == "Search":
    with st.spinner('Displaying...'):
        columns_list = df.columns.tolist()
        columns_default = ['name', 'age', 'address', 'phone_no', 'ward_no', 'gender', 'aadhar_no', 'level_of_disablity', 'category', 'religion', 'email', 'caretaker_name']

        # Data selections
        marital_status = df['martial_status'].unique().tolist()
        ages = df['age'].unique().tolist()
        ward_no = df['ward_no'].unique().astype(int).tolist()
        ward_no.sort()
        genders = df['gender'].unique().tolist()
        level_disabilities = df['level_of_disablity'].unique().tolist()

    # Additional filtering options
    def _additional_filter():
        parental_status = df['parental_status'].unique().tolist()
        family_members = df['no_of_family_members'].unique().astype(int).tolist()
        medical_certificate = df['medical_board_certificate'].unique().tolist()
        type_of_disabilities = df['type_of_disablity'].unique().tolist()
        percentage_disabilities = df['percentage_of_disablity'].unique().tolist()

        col11, col12, col13, col14, col15 = st.columns([1, 6, 1, 6, 1])
        with col12:
            global family_selection,disability_selection,medical_selection,percentage_selection,parental_selection
            family_selection = st.slider('No.of Family Members',
                                        min_value=min(family_members),
                                        max_value=max(family_members),
                                        value=(min(family_members), max(family_members)))
            disability_selection = st.multiselect('Type of Disability',
                                                  type_of_disabilities,
                                                  default=type_of_disabilities)
        with col14:
            medical_selection = st.multiselect('Medical Certificate Status',
                                               medical_certificate,
                                               default=medical_certificate)
            percentage_selection = st.multiselect('Percentage of Disability',
                                                  percentage_disabilities,
                                                  default=percentage_disabilities)
        col21, col22, col23 = st.columns([1, 4, 1])
        with col22:
            parental_selection = st.multiselect('Parental Status',
                                                parental_status,
                                                default=parental_status)

    with stylable_container(key="width_restricter",
                            css_styles=[
                                """
                                {
                                    border-radius: 1em;
                                    width: 70%;
                                    margin: auto;
                                }
                                """,
                            ]):
        with st.form(key='filtered_view', border=False):
            with st.expander("Filter By"):
                col11, col12, col13, col14, col15 = st.columns([1, 6, 1, 6, 1])
                with col12:
                    marital_selection = st.multiselect('Marital Status',
                                                       marital_status,
                                                       default=marital_status)
                with col14:
                    gender_selection = st.multiselect('Gender',
                                                      genders,
                                                      default=genders)
                    level_selection = st.multiselect('Level of Disability',
                                                     level_disabilities,
                                                     default=level_disabilities)
                col21, col22, col23 = st.columns([1, 4, 1])
                with col22:
                    ward_selection = st.multiselect('Ward',
                                                    ward_no,
                                                    default=ward_no)
                on = st.toggle("Show Additional options")
                if on:
                    _additional_filter()

            col1, col2 = st.columns([3, 1])
            with col1:
                with st.expander("Display"):
                    columns_selection = st.multiselect('Select Columns to Display',
                                                        columns_list,
                                                        default=columns_default)
            with col2:
                submit_button = st.form_submit_button(label='Apply Changes', use_container_width=True)

    # Filtered DataFrame
    mask = (df['martial_status'].isin(marital_selection)) & \
           (df['gender'].isin(gender_selection)) & \
           (df['level_of_disablity'].isin(level_selection))
    number_of_result = df[mask].shape[0]
    st.markdown(f'*Available Results: {number_of_result}*')
    fildata = df[mask][columns_selection].reset_index(drop=True)
    st.dataframe(fildata)

    if st.button("Export Data", type='primary'):
        with st.spinner('Generating...'):
            print_pdf()
            with open("Data/export.pdf", "rb") as pdf_file:
                PDFbyte = pdf_file.read()
                st.download_button(label="Download PDF",
                                   data=PDFbyte,
                                   file_name="Exported.pdf",
                                   mime='application/octet-stream')

if selected == "Personal info":
    # --- PDF Layout ---
    def _first_page_information(data):
        table_001 = Table(number_of_rows=23, number_of_columns=2)
        p1fields = {
            "Age": 'age',
            "Address": 'address',
            "Phone No": 'phone_no',
            "Ward No": 'ward_no',
            "House No": 'house_no',
            "Gender": 'gender',
            "CareTaker": 'caretaker_name',
            "Guardian's Name": 'guardian_name',
            "No.of Family Members": 'no_of_family_members',
            "Parental Status": 'parental_status',
            "Marital Status": 'martial_status',
            "Aadhar No": 'aadhar_no',
            "Medical Board Certificate": 'medical_board_certificate',
        }
        p3fields={
            "UID Card": 'UID_card',
            "Percentage of Disability": 'percentage_of_disablity',
            "Type of Disability": 'type_of_disablity',
            "Level of Disability": 'level_of_disablity',
            "Guardianship": 'guardianship',
            "Category": 'category',
            "Classification": 'classification',
            "Religion": 'religion',
            "Social Protections Available": 'social_protection'
        }
        for label, key in p1fields.items():
            table_001.add(Paragraph(label, font="Helvetica-Bold", horizontal_alignment=Alignment.LEFT))
            table_001.add(Paragraph(str(data.get(key, ''))))
        table_001.add(Paragraph("")) 
        table_001.add(Paragraph("")) 
        for label, key in p3fields.items():
            table_001.add(Paragraph(label, font="Helvetica-Bold", horizontal_alignment=Alignment.LEFT))
            table_001.add(Paragraph(str(data.get(key, ''))))
        
        table_001.set_padding_on_all_cells(Decimal(2), Decimal(2), Decimal(2), Decimal(2))
        table_001.no_borders()
        return table_001
    
    def _second_page_information(data):
        table_001 = Table(number_of_rows=4, number_of_columns=2)
        socialfields={
            "Category": 'category',
            "Classification": 'classification',
            "Religion": 'religion',
            "Social Protection": 'social_protection_yes_or_no'
        }
        for label, key in socialfields.items():
            table_001.add(Paragraph(label, font="Helvetica-Bold", horizontal_alignment=Alignment.LEFT))
            table_001.add(Paragraph(str(data.get(key, ''))))
        
        table_001.set_padding_on_all_cells(Decimal(2), Decimal(2), Decimal(2), Decimal(2))
        table_001.no_borders()
        return table_001

    col1, col2, col3 = st.columns([4, 1, 6])
    with col1:
        st.title("View Detailed Info")
        st.text("")
        srch_code = st.text_input("Aadhar No", value="", max_chars=12)

        # --- Fetch Data ---
        try:
            data = indata
            srch_int = srch_code
            mask = (df['aadhar_no'] == srch_int)
            if df[mask].shape[0]:
                st.markdown(f'Found User')
                st.markdown(f'**{df[mask].iloc[0]["name"]}**')
                with st.spinner('Getting Info...'):
                    pdf = Document()
                    page1 = Page()
                    page2 = Page()
                    pdf.add_page(page1)
                    page_layout = SingleColumnLayout(page1)
                    page_layout.vertical_margin = page1.get_page_info().get_height() * Decimal(0.02)
                    page_layout.add(
                        Image(
                            image=Path("assets/pbanner.png"),
                            width=Decimal(466),
                            height=Decimal(68),
                        )
                    )
                    page_layout.add(
                        Paragraph(
                            str(df[mask].iloc[0]["name"]), font_color=HexColor("#283592"), font_size=Decimal(25)
                        )
                    )
                    page_layout.add(_first_page_information(df[mask].iloc[0]))
                    page_layout.add(Paragraph(" "))

                    #Page 2
                    pdf.add_page(page2)
                    page_layout = SingleColumnLayout(page2)
                    page_layout.vertical_margin = page2.get_page_info().get_height() * Decimal(0.02)
                    page_layout.add(_second_page_information(df[mask].iloc[0]))

                    with open("Data/cacheout.pdf", "wb") as pdf_file_handle:
                        PDF.dumps(pdf_file_handle, pdf)
                    with col3:
                        with open("Data/cacheout.pdf", "rb") as pdf_file:
                            PDFbyte = pdf_file.read()
                            pdf_viewer(input=PDFbyte, width=700)
                            with col1:
                                st.download_button(label="Download Report",
                                                   data=PDFbyte,
                                                   file_name=str(df[mask].iloc[0]["name"]) + ".pdf",
                                                   mime='application/octet-stream')
            elif not srch_int:
                st.markdown('*Enter UID Number*')
            else:
                st.markdown('*The person is not available or there may be a mistake in data entry*')
        except requests.exceptions.RequestException as e:
            st.error(f"Error fetching data: {e}")
