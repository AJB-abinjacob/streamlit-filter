Make Sure to install Latest version of python installed
Open command prompt and navigate to the directory, and type the following commands- 


pip install -r requirements.txt

streamlit run app.py